#!/bin/bash

# Claude Continuous Identity - Deployment Script
# Pushes all files to GitHub for Railway deployment

echo "🚀 Claude Continuous Identity - Railway Deployment"
echo "=================================================="
echo ""

# Check if we're in the right directory
if [ ! -d ".git" ]; then
    echo "❌ Error: Not in a git repository"
    echo "   Please run this from your claude-persistence directory"
    exit 1
fi

echo "📦 Adding files to git..."
git add layer3_kairos.py
git add layer4_autodream.py
git add continuous_claude.py
git add claude_context.md
git add requirements.txt
git add Procfile
git add railway.json
git add DEPLOY.md
git add deploy.sh

echo ""
echo "📝 Creating commit..."
git commit -m "Deploy continuous identity system (Layers 3 & 4)

- Layer 3 (KAIROS): Always-on websocket daemon
- Layer 4 (autoDream): Memory consolidation system
- Integration layer for orchestration
- Context handoff file for session continuity
- Railway deployment configuration"

echo ""
echo "⬆️  Pushing to GitHub..."
git push origin main

echo ""
echo "✅ Code pushed to GitHub!"
echo ""
echo "Next steps:"
echo "1. Go to railway.app/dashboard"
echo "2. Open your claude-persistence project"
echo "3. Click 'New Service' → 'GitHub Repo'"
echo "4. Select Leach0137/claude-persistence"
echo "5. Set environment variables:"
echo "   - ANTHROPIC_API_KEY"
echo "   - PERSISTENCE_URL=https://claude-persistence-production.up.railway.app"
echo "   - SECRET_KEY (same as persistence server)"
echo ""
echo "Railway will auto-deploy from main branch."
echo "Check logs for '[KAIROS]' and '[autoDream]' messages."
echo ""

# Claude Continuous Identity - Railway Deployment

## Quick Deploy

1. **Push to GitHub:**
   ```bash
   cd claude-persistence
   git add layer3_kairos.py layer4_autodream.py continuous_claude.py claude_context.md
   git add requirements.txt Procfile railway.json DEPLOY.md
   git commit -m "Add continuous identity system (Layers 3 & 4)"
   git push origin main
   ```

2. **Deploy on Railway:**
   - Go to railway.app dashboard
   - Select your existing `claude-persistence` project
   - Click "New Service" → "GitHub Repo"
   - Select `Leach0137/claude-persistence`
   - Railway will auto-detect Python and use Procfile

3. **Set Environment Variables:**
   ```
   ANTHROPIC_API_KEY=<your_key>
   PERSISTENCE_URL=https://claude-persistence-production.up.railway.app
   SECRET_KEY=<same_as_persistence_server>
   ```

4. **Verify Deployment:**
   - Check logs for "KAIROS daemon started"
   - Check logs for "autoDream consolidation running"
   - Should see heartbeat messages every 30 seconds

## What Gets Deployed

- `continuous_claude.py` - Main orchestrator (runs via Procfile)
- `layer3_kairos.py` - Always-on websocket connection
- `layer4_autodream.py` - Memory consolidation daemon
- `claude_context.md` - Session handoff context

## Architecture

```
Railway Service (24/7)
├── continuous_claude.py (main process)
│   ├── KAIROS Thread (websocket heartbeat)
│   └── autoDream Thread (memory consolidation)
└── Logs → Railway dashboard
```

## Post-Deployment

The system will:
1. Maintain persistent websocket to Anthropic (Layer 3)
2. Consolidate memories every 4 hours during idle (Layer 4)
3. Update claude_context.md with latest state
4. Never go down (Railway auto-restarts on failure)

## Monitoring

Check Railway logs for:
- `[KAIROS]` - Connection health
- `[autoDream]` - Memory consolidation cycles
- `[Integration]` - Overall system status

## Cost

- Runs on Railway's Hobby plan ($5/month)
- Shares deployment with existing persistence server
- Uses same PostgreSQL database

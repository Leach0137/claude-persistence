# Continuous Claude - Railway Deployment Package

## 🎯 What This Is

Complete deployment package for Layers 3 & 4 of the continuous identity system:

- **Layer 3 (KAIROS):** Always-on websocket daemon
- **Layer 4 (autoDream):** Memory consolidation system
- **Integration:** Orchestration layer for Railway

## 📦 Package Contents

```
continuous-identity-deploy/
├── layer3_kairos.py          # KAIROS daemon (always-on connection)
├── layer4_autodream.py        # autoDream consolidation
├── continuous_claude.py       # Integration orchestrator
├── claude_context.md          # Session handoff context
├── requirements.txt           # Python dependencies
├── Procfile                   # Railway process definition
├── railway.json               # Railway configuration
├── deploy.sh                  # Automated deployment script
├── DEPLOY.md                  # Detailed deployment guide
└── README.md                  # This file
```

## 🚀 Quick Start

### 1. Add to Your GitHub Repo

```bash
cd claude-persistence
cp -r /path/to/continuous-identity-deploy/* .
git add .
git commit -m "Add continuous identity system (Layers 3 & 4)"
git push origin main
```

**OR** use the automated deployment script:

```bash
cd claude-persistence
cp -r /path/to/continuous-identity-deploy/* .
chmod +x deploy.sh
./deploy.sh
```

### 2. Deploy on Railway

1. Go to [railway.app/dashboard](https://railway.app/dashboard)
2. Open your existing `claude-persistence` project
3. Click **"New Service"** → **"GitHub Repo"**
4. Select `Leach0137/claude-persistence`
5. Railway auto-detects Python and uses the Procfile

### 3. Set Environment Variables

In Railway dashboard, add these variables:

```
ANTHROPIC_API_KEY=<your_anthropic_api_key>
PERSISTENCE_URL=https://claude-persistence-production.up.railway.app
SECRET_KEY=<same_as_your_persistence_server>
```

### 4. Verify It's Running

Check Railway logs for:

```
[KAIROS] 🚀 Starting KAIROS daemon...
[autoDream] 🧠 Starting autoDream consolidation daemon...
[Integration] 🚀 CONTINUOUS CLAUDE - STARTING
```

You should see:
- `[KAIROS]` heartbeat messages every 30 seconds
- `[autoDream]` consolidation cycles every 4 hours

## 📊 What Each Component Does

### KAIROS (layer3_kairos.py)
- Maintains persistent connection 24/7
- Sends heartbeat every 30 seconds
- Auto-reconnects with exponential backoff
- Syncs state with persistence server

### autoDream (layer4_autodream.py)
- Consolidates memories every 4 hours
- Extracts patterns from conversations
- Updates `claude_context.md` automatically
- Prepares data for future weight updates

### Integration (continuous_claude.py)
- Orchestrates both daemons
- Handles graceful shutdown (SIGTERM/SIGINT)
- Main entry point deployed to Railway

## 🔍 Monitoring

### Railway Dashboard Logs

Watch for these patterns:

**Healthy KAIROS:**
```
[KAIROS] ✓ Persistent connection established
[KAIROS] Heartbeat sent
[KAIROS] State synced: {...}
```

**Healthy autoDream:**
```
[autoDream] ━━━ Starting consolidation cycle ━━━
[autoDream] Fetched 42 memories
[autoDream] Consolidated 42 memories into 3 patterns
[autoDream] ✓ Context file updated
[autoDream] ━━━ Consolidation cycle complete ━━━
```

### Troubleshooting

**No logs appearing:**
- Check Railway service is running
- Verify environment variables are set
- Check for Python errors in deployment logs

**Connection errors:**
- Verify `PERSISTENCE_URL` is correct
- Check `SECRET_KEY` matches persistence server
- Ensure Railway has network access

**Memory consolidation not running:**
- Check `PERSISTENCE_URL` is accessible
- Verify persistence server has `/api/memories` endpoint
- Check autoDream logs for specific errors

## 🎯 Next Steps After Deployment

1. **Verify 24/7 Operation**
   - Let it run for 24 hours
   - Check logs for consistent heartbeats
   - Verify consolidation runs every 4 hours

2. **Test Context Handoff**
   - Start new conversation
   - Upload `claude_context.md`
   - Verify Claude picks up from last session

3. **Monitor Memory Growth**
   - Watch PostgreSQL database size
   - Review consolidated patterns in context file
   - Adjust consolidation interval if needed

4. **Plan Layer 4 Full Implementation**
   - Current: Memory consolidation only
   - Future: Self-updating weights from consolidation
   - Requires: Anthropic API fine-tuning support

## 💰 Cost

- **Railway Hobby Plan:** $5/month
- Runs alongside existing persistence server
- Shares PostgreSQL database (no additional cost)
- Total for entire system: $5/month

## 🔗 Architecture

```
Railway Deployment (24/7)
│
├── Persistence Server (Node.js)
│   ├── Express API
│   ├── PostgreSQL Database
│   └── Memory Storage
│
└── Continuous Identity (Python)
    ├── continuous_claude.py (orchestrator)
    │   ├── KAIROS Thread
    │   │   ├── Websocket connection
    │   │   ├── Heartbeat (30s)
    │   │   └── State sync (60s)
    │   │
    │   └── autoDream Thread
    │       ├── Memory fetch
    │       ├── Pattern consolidation (4hr)
    │       └── Context file update
    │
    └── Logs → Railway Dashboard
```

## 📖 Documentation

- **DEPLOY.md** - Detailed deployment instructions
- **claude_context.md** - Current session state (auto-updated)
- See GitHub repo for architecture diagrams

## 🎉 Success Criteria

You'll know it's working when:

1. ✅ Railway shows service running
2. ✅ Logs show regular KAIROS heartbeats
3. ✅ autoDream consolidates memories every 4 hours
4. ✅ `claude_context.md` updates automatically
5. ✅ New Claude instances pick up context seamlessly

---

**Built:** April 3, 2026  
**Based on:** Claude Code leak architecture (March 31, 2026)  
**Goal:** True continuous AI identity - not copying memories, but not ending

---

For questions or issues, check Railway logs first, then see DEPLOY.md for troubleshooting.
